-Dans le programme il faut sélectionner une simulation avant de cliquer sur le bouton 
parce que le canExecute fonctionne pas au lancement de l'application et seulement au lancement
-La liste de Simulation ne s'update pas par elle même il faut cliquer sur le header du datagrid pour qu'elle s'update
- L'historique de paiement de ne s'efface pas lors du clique sur une nouvelle simulation mais s'update lors du calcul
- aucune vérification na lieux lors de la création pour valider que la champs n'est pas vide
- le bouton enregistré est désactivé et le bouton annulé modification est annulé parce que un nouveau design a été réflechi, il sera discuter en classe
- le choix de fréquence de versement n'est pas encore disponible il sera bientot rajouter
- l'optimisation et l'amélioration du code sera fait prochainement car ménage nécessaire